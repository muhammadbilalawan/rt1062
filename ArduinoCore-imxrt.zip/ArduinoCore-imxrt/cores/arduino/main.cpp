#ifdef ARDUINO_MAIN

#include "Arduino.h"

void  __attribute__((weak)) setup() {

}

void  __attribute__((weak)) loop() {

}

extern void (* __isr_vector[])(void);
#define NVIC_NUM_INTERRUPTS	sizeof(__isr_vector) / sizeof(__isr_vector[0])

__attribute__ ((used, aligned(1024)))
#define NVIC_NUM_INTERRUPTS     160
#define DMA_NUM_CHANNELS        32

void (* _VectorsRam[NVIC_NUM_INTERRUPTS+16])(void);
//void (* volatile _VectorsRam[256])(void);
#define NVIC_SET_PRIORITY(irqnum, priority)  (*((volatile uint8_t *)0xE000E400 + (irqnum)) = (uint8_t)(priority))
#define NVIC_GET_PRIORITY(irqnum) (*((uint8_t *)0xE000E400 + (irqnum)))

int  __attribute__((weak)) main()
{
	for (int i = 0; i < NVIC_NUM_INTERRUPTS+16; i++)
		_VectorsRam[i] = __isr_vector[i];//&IntDefaultHandler;
	for (int i = 0; i < NVIC_NUM_INTERRUPTS+16; i++)
		NVIC_SET_PRIORITY(i, 128);

__disable_irq();
    unsigned int * pSCB_VTOR = (unsigned int *) 0xE000ED08;
        *pSCB_VTOR = (unsigned int)_VectorsRam;

//    unsigned int * pSCB_VTOR = (unsigned int *) 0xE000ED08;
//    *pSCB_VTOR = (unsigned int)_VectorsRam;
 __enable_irq();

    init();
    setup();
    for (;;)
    {
        loop();
yield();
    }
}

#endif
